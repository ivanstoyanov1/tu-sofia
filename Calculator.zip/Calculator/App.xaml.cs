﻿namespace Calculator
{
    /// <summary>
    ///  Main application class
    /// </summary>
    public partial class App
    {
    }
}