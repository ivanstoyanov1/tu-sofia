﻿namespace Calculator.DigitControl
{
    public class IndicatorState
    {
        public float Value { get; set; }
        public bool IsError { get; set; }
        public bool IsMemory { get; set; }
        public int MantissaLength { get; set; }                          
    }
}
