# Calculator.WPF
Windows calculator. New, real-like view.

**Technologies used:**

 - Microsoft .Net 4.5 Framework

 - Pure WPF Framework

 - MVVM Pattern